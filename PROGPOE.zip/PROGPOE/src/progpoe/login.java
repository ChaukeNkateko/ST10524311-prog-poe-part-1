/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progpoe;
import java.util.Scanner;
import java.util.regex.Pattern;
/**
 *
 * @author Student
 */
public class login {
    public static final Pattern SA_CELL_PATTERN = Pattern.compile("^\\+27\\d{9}$");

    static void runLoginWorkflow(Scanner input) {
        System.out.println("Login to you account");
        System.out.println("Enter your username");
        String username = input.nextLine();
        
        System.out.println("Enter your password:");
        String password = input.nextLine();
        
       
    }
  private String username;
    private String password;
    private String phoneNumber;
    private String firstName;
    private String lastName;

    // Helper method to validate username 
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    //  method to validate password complexity 
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) return false;
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSpecial = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            else if (Character.isDigit(c)) hasDigit = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasUpper && hasDigit && hasSpecial;
    }

    //  method to validate phone number
    public boolean checkPhoneNumber(String phoneNumber) {
        return (phoneNumber.startsWith("+27") || phoneNumber.startsWith("27")) && phoneNumber.length() >= 10;
    }

  
    public String registerUser(String username, String password, String phoneNumber, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkPhoneNumber(phoneNumber)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        
       
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;

        return "Registration successful.";
    }

    
    public boolean loginUser(String username, String password) {
        if (this.username == null || this.password == null) return false;
        return username.equals(this.username) && password.equals(this.password);
    }

    
    public String returnLoginStatus(String username, String password) {
        if (loginUser(username, password)) {
            return "Welcome " + this.firstName + " " + this.lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    private static class logiInstance {

        public logiInstance() {
        }
    }
    

}

    
           
    
    
    
    
  

   

          

