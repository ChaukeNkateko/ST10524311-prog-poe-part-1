/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progpoe;
 import java.util.Scanner;
import java.util.regex.Pattern;
/**
 *
 * @author Student
 */
public class PROGPOE {
    public static final Pattern SA_CELL_PATTERN = Pattern.compile("^\\+27\\d{9}$");

    /**
     */
   
            
    public static String username;
    public static String password;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String firstName;
        String lastName;
        String phoneNumber;

        System.out.println("=== ACCOUNT REGISTRATION ===");
        System.out.print("Enter your first name: ");
        firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        lastName = input.nextLine();

        //  Username Validation 
        while (true) {
            System.out.print("Enter your username: ");
            username = input.nextLine();

            if (checkUserName(username)) {
                System.out.println("username successfully captured");
                break;
            } else {
                System.out.println("Username is not successfully captured.");
                System.out.println("Username must contain an _ character.");
                System.out.println("Username must be at least 4 characters long.");
            }
        }

        //  Phone Number Validation 
        while (true) {
            System.out.print("Enter your cell phone number: ");
            phoneNumber = input.nextLine();

            if (CheckPhoneNumber(phoneNumber)) {
                System.out.println("Your cell phone number is successfully captured.");
                break;
            } else {
                System.out.println("Your cell phone number is not correctly formatted.");
                System.out.println("Your cell phone number must start with the SA code +27.");
            }
        }

        //  Password Validation 
        while (true) {
            System.out.print("Enter a password: ");
            password = input.nextLine();

            if (checkPassword(password)) {
                System.out.println("password successfully captured.");
                break;
            } else {
                System.out.println("password is not correctly formatted.");
                System.out.println("password must between 10 characters long");
                System.out.println("password must contain a capital letter");
                System.out.println("password must contain a lowercase letter");
                System.out.println("password must contain a number");
                System.out.println("password must contain a special character");
            }
        }

        System.out.println(" Registration Successful! Handing over to Login..");
        
       
        login.runLoginWorkflow(input);

        input.close();
    }

     

    public static boolean CheckPhoneNumber(String phoneNumber) {
        String regex ="^(\\+?27)\\d{9}$";
        return Pattern.matches(regex, phoneNumber);
            
       }
        
    

    public static boolean checkPassword(String password) {
        if (password.length() < 10) {
            return false;
        }

        boolean hasCapitalLetter = false;
        boolean hasLowerCase = false;
        boolean hasSpecialCharacter = false;
        boolean hasNumber = false;

        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);
            if (Character.isUpperCase(ch)) hasCapitalLetter = true;
            if (Character.isLowerCase(ch)) hasLowerCase = true;
            if (Character.isDigit(ch)) hasNumber = true;
            if (!Character.isLetterOrDigit(ch)) hasSpecialCharacter = true;
        }

        return hasCapitalLetter && hasLowerCase && hasNumber && hasSpecialCharacter;
    }

    public static boolean checkUserName(String username) {
        if (username.length() < 4) {
            return false;
        }
        int hashCount = 0;
        int atCount = 0;
        for (int i = 0; i < username.length(); i++) {
            char ch = username.charAt(i);
            if (ch == '_') hashCount++;
            if (ch == '_') atCount++;
        }
        return hashCount > 0 && atCount > 0;
    }
}
        // TODO code application logic here
    
    
