/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package progpoe;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class loginTest {
    private login loginInstance;
    
    public loginTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
     loginInstance = new login() ;  
    }
    
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testRegisterUser() {
        //  Test Successful Registration
        String success = loginInstance.registerUser("kyl_1", "Ch&ssec@ke99!", "+27838968976", "Kyle", "Smith");
        assertEquals("Registration successful.", success);

        //  Test Invalid Username 
        String invalidUser = loginInstance.registerUser("kyle!!!!!!!", "Ch&ssec@ke99!", "+27838968976", "Kyle", "Smith");
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is"
                + " no more than 5 characters in length.", invalidUser);

        // Test Invalid Password 
        String invalidPass = loginInstance.registerUser("kyl_1", "password", "+27838968976", "Kyle", "Smith");
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least eight "
                + "characters, a capital letter, a number, and a special character.", invalidPass);

        // Test Invalid Cell Phone Number
        String invalidCell = loginInstance.registerUser("kyl_1", "Ch&ssec@ke99!", "08966553", "Kyle", "Smith");
        assertEquals("Cell phone number incorrectly formatted or does not contain international code.", invalidCell);
    }

    @Test
    public void testLoginUser() {
        // Register the user profile first
        loginInstance.registerUser("kyl_1", "Ch&ssec@ke99!", "+27838968976", "Kyle", "Smith");

        // Assert true for correct credentials, false for wrong ones
        assertTrue(loginInstance.loginUser("kyl_1", "Ch&ssec@ke99!"), "Correct credentials should return true");
        assertFalse(loginInstance.loginUser("wrongUser", "wrongPassword"), "Incorrect credentials should return false");
    }

    @Test
    public void testReturnLoginStatus() {
        // Register the user profile first
        loginInstance.registerUser("kyl_1", "Ch&ssec@ke99!", "+27838968976", "Kyle", "Smith");

        // Verify successful login custom message string
        String successMessage = loginInstance.returnLoginStatus("kyl_1", "Ch&ssec@ke99!");
        assertEquals("Welcome Kyle Smith, it is great to see you again.", successMessage);

        // Verify failed login custom message string
        String failMessage = loginInstance.returnLoginStatus("wrongUser", "wrongPassword");
        assertEquals("Username or password incorrect, please try again.", failMessage);
    }
}  


